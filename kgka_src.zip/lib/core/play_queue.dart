import 'dart:math';

/// 播放队列模型：主队列（可洗牌）+ 追加播放队列（插播）+ 真实播放历史。
///
/// 播放优先级：
/// 1. 历史前进：用户点过“上一首”后，再点“下一首”会沿历史回到原来那首；
/// 2. 追加播放队列：先进先出，队首优先（顺序/随机播放都生效）；
/// 3. 主队列游标：随机模式下按洗牌后的顺序；一轮播完回到队首，不重洗。
///
/// [T] 为歌曲对象。[PlayQueue.identity] 用于判断两首歌是否同一首
/// （项目里的 Song 没有重写 `==`，不能依赖对象相等性判等）。
class PlayQueue<T> {
  PlayQueue({required this.identity, Random? random})
      : _random = random ?? Random();

  /// 历史最多保留的条数，避免长时间使用后内存无限增长。
  static const int maxHistoryLength = 200;

  /// 歌曲身份提取函数，返回值相同的两首歌视为同一首。
  final String Function(T) identity;

  final Random _random;

  final List<T> _active = <T>[];
  List<T>? _ordered;
  final List<T> _upNext = <T>[];
  final List<T> _history = <T>[];
  int _historyIndex = -1;
  int _cursor = 0;
  bool _shuffled = false;

  /// 当前播放顺序（随机模式下即洗牌后的顺序）。UI 只读，不要直接修改。
  List<T> get active => _active;

  /// 歌单原始顺序；从未洗牌时为空。
  List<T> get ordered => _ordered ?? const [];

  /// 追加播放队列（插播），队首最先播放。UI 只读。
  List<T> get upNext => _upNext;

  /// 主队列中“下一首”的位置。
  int get cursor => _cursor;

  /// 当前是否处于洗牌顺序。
  bool get isShuffled => _shuffled;

  /// 当前播放历史（按实际播放顺序）。
  List<T> get history => _history;

  /// 播放历史游标（指向当前正在播放的歌）。
  int get historyIndex => _historyIndex;

  /// 追加播放队列是否非空。
  bool get hasUpNext => _upNext.isNotEmpty;

  /// 主队列是否为空。
  bool get isEmpty => _active.isEmpty;

  /// 主队列长度。
  int get length => _active.length;

  /// 是否存在“回退后可以前进”的历史路径。
  bool get canGoForwardInHistory =>
      _historyIndex >= 0 && _historyIndex < _history.length - 1;

  /// 载入新歌单：重建主队列、清空追加队列与播放历史。
  void setSource(Iterable<T> items, {T? current}) {
    final source = _unique(items);
    _active
      ..clear()
      ..addAll(source);
    _ordered = List<T>.of(source);
    _upNext.clear();
    _history.clear();
    _historyIndex = -1;
    _cursor = 0;
    _shuffled = false;
    if (current != null) {
      _moveCursorAfter(current);
      _record(current);
    }
  }

  /// 切换洗牌顺序。
  ///
  /// [value] 为 true 时把主队列洗牌，当前歌曲放到首位（保证一轮从它开始）；
  /// 为 false 时还原 [setSource] 记录的原始顺序。
  void setShuffled(bool value, {T? current}) {
    if (_active.isEmpty) {
      _shuffled = false;
      _cursor = 0;
      return;
    }

    if (!value) {
      final ordered = _ordered;
      if (ordered == null) {
        _shuffled = false;
        return;
      }
      _active
        ..clear()
        ..addAll(ordered);
      _shuffled = false;
      final cur = current ?? _currentFromHistory;
      if (cur != null && _contains(_active, cur)) {
        _cursor = (_indexOf(_active, cur) + 1) % _active.length;
      } else {
        _cursor = 0;
      }
      return;
    }

    final base = _ordered ?? List<T>.of(_active);
    _ordered ??= List<T>.of(base);
    final cur = current ?? _currentFromHistory;
    final hasCurrent = cur != null && _contains(base, cur);
    final rest = <T>[];
    for (final item in base) {
      if (cur != null && identity(item) == identity(cur)) {
        continue;
      }
      rest.add(item);
    }
    rest.shuffle(_random);

    _active.clear();
    if (hasCurrent) {
      _active.add(cur!);
    }
    _active.addAll(rest);
    _shuffled = true;
    // 有当前歌时它排首位、游标指向第二首；没有当前歌（例如正在播放
    // 追加队列的歌曲）时从洗牌后的第一首开始，避免漏掉一首。
    _cursor = hasCurrent && _active.length > 1 ? 1 : 0;
  }

  /// 用户从队列中点歌：游标移到它后面，并记录到播放历史
  /// （会截断回退后产生的旧前进路径）。
  void select(T item) {
    _moveCursorAfter(item);
    _record(item);
  }

  /// 记录一次播放（与当前历史项相同时忽略）。
  void record(T item) {
    _record(item);
  }

  /// 追加到插播队列末尾；同一首歌只保留一条（重复添加等于移到末尾）。
  void addUpNext(T item) {
    final key = identity(item);
    _upNext.removeWhere((candidate) => identity(candidate) == key);
    _upNext.add(item);
  }

  /// 取出并移除指定位置的插播歌曲；位置非法时返回 null。
  T? takeUpNextAt(int index) {
    if (index < 0 || index >= _upNext.length) {
      return null;
    }
    return _upNext.removeAt(index);
  }

  /// 移除指定位置的插播歌曲。
  void removeUpNextAt(int index) {
    if (index < 0 || index >= _upNext.length) {
      return;
    }
    _upNext.removeAt(index);
  }

  /// 清空插播队列。
  void clearUpNext() {
    _upNext.clear();
  }

  /// 向主队列末尾追加（私人 FM 批次）。
  void appendToActive(Iterable<T> items) {
    final additions = <T>[
      for (final item in _unique(items))
        if (!_contains(_active, item)) item,
    ];
    if (additions.isEmpty) {
      return;
    }
    _active.addAll(additions);
    final ordered = _ordered;
    if (ordered != null) {
      ordered.addAll(additions);
    }
  }

  /// 取下一首；返回 null 表示没有可播放的歌。
  ///
  /// [current] 用于在历史里定位当前歌曲（不传则取历史游标所指的歌）。
  T? next({T? current}) {
    if (canGoForwardInHistory) {
      _historyIndex++;
      return _history[_historyIndex];
    }

    if (_upNext.isNotEmpty) {
      final item = _upNext.removeAt(0);
      _record(item);
      return item;
    }

    if (_active.isEmpty) {
      _cursor = 0;
      return null;
    }
    if (_active.length == 1) {
      final only = _active.first;
      _record(only);
      return only;
    }

    var index = _cursor;
    if (index < 0 || index >= _active.length) {
      index = 0;
    }
    final item = _active[index];
    _cursor = (index + 1) % _active.length;
    _record(item);
    return item;
  }

  /// 取上一首（真实听过的上一首优先）；返回 null 表示没有可回退的歌。
  T? previous({T? current}) {
    if (_historyIndex > 0) {
      _historyIndex--;
      return _history[_historyIndex];
    }

    if (_active.isEmpty) {
      return null;
    }

    final cur = current ?? _currentFromHistory;
    final index = cur == null ? -1 : _indexOf(_active, cur);
    if (index > 0) {
      final item = _active[index - 1];
      // 回退后，下一次“下一首”从这首之后继续，避免跳过它。
      _cursor = index;
      _record(item);
      return item;
    }
    if (_active.length > 1) {
      final item = _active.last;
      _cursor = 0;
      _record(item);
      return item;
    }
    return null;
  }

  /// 从持久化状态恢复（用于冷启动）。
  void restore({
    required Iterable<T> active,
    Iterable<T>? ordered,
    Iterable<T> upNext = const [],
    int cursor = 0,
    bool shuffled = false,
    Iterable<T> history = const [],
    int historyIndex = -1,
  }) {
    final activeList = _unique(active);
    _active
      ..clear()
      ..addAll(activeList);
    _ordered = ordered == null ? null : List<T>.of(_unique(ordered));
    _upNext
      ..clear()
      ..addAll(_unique(upNext));
    _history
      ..clear()
      ..addAll(history);

    _historyIndex = historyIndex;
    if (_historyIndex >= _history.length) {
      _historyIndex = _history.length - 1;
    }
    if (_historyIndex < -1) {
      _historyIndex = -1;
    }

    _shuffled = shuffled && _active.isNotEmpty;
    _cursor = cursor;
    if (_cursor < 0 || _cursor >= _active.length) {
      _cursor = 0;
    }
  }

  T? get _currentFromHistory {
    if (_historyIndex >= 0 && _historyIndex < _history.length) {
      return _history[_historyIndex];
    }
    return null;
  }

  void _moveCursorAfter(T item) {
    final index = _indexOf(_active, item);
    if (index < 0) {
      _cursor = 0;
      return;
    }
    _cursor = _active.isEmpty ? 0 : (index + 1) % _active.length;
  }

  void _record(T item) {
    final current = _currentFromHistory;
    if (current != null && identity(current) == identity(item)) {
      return;
    }
    if (_historyIndex >= 0 && _historyIndex < _history.length - 1) {
      _history.removeRange(_historyIndex + 1, _history.length);
    }
    _history.add(item);
    _historyIndex = _history.length - 1;

    if (_history.length > maxHistoryLength) {
      final overflow = _history.length - maxHistoryLength;
      _history.removeRange(0, overflow);
      _historyIndex -= overflow;
      if (_historyIndex < 0) {
        _historyIndex = 0;
      }
    }
  }

  List<T> _unique(Iterable<T> items) {
    final seen = <String>{};
    final result = <T>[];
    for (final item in items) {
      final key = identity(item);
      if (key.isEmpty) {
        // 没有身份信息的歌不去重，避免把不同的本地歌曲误合成一首。
        result.add(item);
        continue;
      }
      if (seen.add(key)) {
        result.add(item);
      }
    }
    return result;
  }

  int _indexOf(List<T> items, T item) {
    final key = identity(item);
    if (key.isEmpty) {
      for (var i = 0; i < items.length; i++) {
        if (identical(items[i], item)) {
          return i;
        }
      }
      return -1;
    }
    for (var i = 0; i < items.length; i++) {
      if (identity(items[i]) == key) {
        return i;
      }
    }
    return -1;
  }

  bool _contains(List<T> items, T item) => _indexOf(items, item) >= 0;
}
