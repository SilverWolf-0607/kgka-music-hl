import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:kgka_music_hl/core/play_queue.dart';

void main() {
  PlayQueue<String> buildQueue({int seed = 7}) {
    return PlayQueue<String>(identity: (song) => song, random: Random(seed));
  }

  test('“下一首播放”按添加顺序播放，且不修改主队列', () {
    final queue = buildQueue();
    queue.setSource(const ['a', 'b', 'c'], current: 'a');

    queue.addUpNext('x');
    queue.addUpNext('y');

    expect(queue.active, const ['a', 'b', 'c']);
    expect(queue.upNext, const ['x', 'y']);

    expect(queue.next(current: 'a'), 'x');
    expect(queue.next(current: 'x'), 'y');
    // 追加队列播完后，继续沿主队列往下走。
    expect(queue.next(current: 'y'), 'b');
  });

  test('重复添加同一首歌只保留一条，并移到追加队列末尾', () {
    final queue = buildQueue();
    queue.setSource(const ['a'], current: 'a');

    queue.addUpNext('x');
    queue.addUpNext('y');
    queue.addUpNext('x');

    expect(queue.upNext, const ['y', 'x']);
  });

  test('随机播放等于洗牌主队列：当前歌置首，游标指向下一首', () {
    final queue = buildQueue();
    queue.setSource(const ['a', 'b', 'c', 'd'], current: 'c');

    queue.setShuffled(true, current: 'c');

    expect(queue.isShuffled, isTrue);
    expect(queue.active.length, 4);
    expect(queue.active.toSet(), const {'a', 'b', 'c', 'd'});
    expect(queue.active.first, 'c');
    expect(queue.cursor, 1);
  });

  test('随机顺序一轮内不重复，一轮结束后不重洗、回到队首', () {
    final queue = buildQueue();
    queue.setSource(const ['a', 'b', 'c', 'd', 'e'], current: 'a');
    queue.setShuffled(true, current: 'a');

    final order = List<String>.of(queue.active);
    final shuffledSnapshot = List<String>.of(queue.active);

    var current = order.first;
    for (var i = 1; i < order.length; i++) {
      final next = queue.next(current: current);
      expect(next, order[i]);
      current = next!;
    }
    // 一轮播完：不重洗，回到队首。
    expect(queue.next(current: current), order.first);
    expect(queue.active, shuffledSnapshot);
    expect(queue.isShuffled, isTrue);
  });

  test('关闭随机后还原歌单原始顺序', () {
    final queue = buildQueue();
    queue.setSource(const ['a', 'b', 'c', 'd'], current: 'b');
    final original = List<String>.of(queue.active);

    queue.setShuffled(true, current: 'b');
    queue.setShuffled(false, current: 'b');

    expect(queue.isShuffled, isFalse);
    expect(queue.active, original);
    expect(queue.cursor, 2);
  });

  test('上一首回到真实听过的歌（包括已经播完的追加歌曲）', () {
    final queue = buildQueue();
    queue.setSource(const ['a', 'b', 'c'], current: 'a');
    queue.addUpNext('x');

    expect(queue.next(current: 'a'), 'x');
    expect(queue.next(current: 'x'), 'b');

    expect(queue.previous(current: 'b'), 'x');
    expect(queue.previous(current: 'x'), 'a');
    // 回退后再前进，沿原历史回到刚才那首。
    expect(queue.next(current: 'a'), 'x');
    expect(queue.next(current: 'x'), 'b');
  });

  test('随机模式下添加“下一首播放”不改变主队列顺序和游标', () {
    final queue = buildQueue();
    queue.setSource(const ['a', 'b', 'c', 'd'], current: 'b');
    queue.setShuffled(true, current: 'b');

    final orderBefore = List<String>.of(queue.active);
    final cursorBefore = queue.cursor;

    queue.addUpNext('x');

    expect(queue.active, orderBefore);
    expect(queue.cursor, cursorBefore);
    expect(queue.upNext, const ['x']);
  });

  test('追加队列非空时，随机模式也优先播放追加队列', () {
    final queue = buildQueue();
    queue.setSource(const ['a', 'b', 'c'], current: 'a');
    queue.setShuffled(true, current: 'a');
    queue.addUpNext('x');

    expect(queue.next(current: 'a'), 'x');
    final after = queue.next(current: 'x');
    expect(after, isNot('x'));
    expect(queue.active.contains(after), isTrue);
  });

  test('单曲队列也能正常过渡到追加歌曲并回到原曲', () {
    final queue = buildQueue();
    queue.setSource(const ['a'], current: 'a');
    queue.addUpNext('x');

    expect(queue.next(current: 'a'), 'x');
    expect(queue.next(current: 'x'), 'a');
  });

  test('历史为空时，上一首回退到主队列上一首，下一首从它之后继续', () {
    final queue = buildQueue();
    queue.setSource(const ['a', 'b', 'c'], current: 'b');

    expect(queue.previous(current: 'b'), 'a');
    expect(queue.next(current: 'a'), 'b');
  });

  test('移除/清空追加队列不影响主队列', () {
    final queue = buildQueue();
    queue.setSource(const ['a', 'b'], current: 'a');
    queue.addUpNext('x');
    queue.addUpNext('y');

    queue.removeUpNextAt(0);
    expect(queue.upNext, const ['y']);
    expect(queue.takeUpNextAt(0), 'y');
    expect(queue.hasUpNext, isFalse);

    queue.addUpNext('z');
    queue.clearUpNext();
    expect(queue.hasUpNext, isFalse);
    expect(queue.active, const ['a', 'b']);
  });

  test('正在播放追加歌曲时切随机，不会漏掉洗牌后的第一首', () {
    final queue = buildQueue();
    queue.setSource(const ['a', 'b', 'c'], current: 'a');
    queue.addUpNext('x');

    expect(queue.next(current: 'a'), 'x');
    queue.setShuffled(true, current: 'x');

    expect(queue.active.length, 3);
    expect(queue.cursor, 0);
    final first = queue.active.first;
    expect(queue.next(current: 'x'), first);
  });

  test('持久化恢复后，队列/追加队列/游标/历史都可用', () {
    final queue = buildQueue(seed: 3);
    queue.restore(
      active: const ['d', 'b', 'a', 'c'],
      ordered: const ['a', 'b', 'c', 'd'],
      upNext: const ['x'],
      cursor: 2,
      shuffled: true,
      history: const ['c', 'd'],
      historyIndex: 1,
    );

    expect(queue.active, const ['d', 'b', 'a', 'c']);
    expect(queue.ordered, const ['a', 'b', 'c', 'd']);
    expect(queue.upNext, const ['x']);
    expect(queue.cursor, 2);
    expect(queue.isShuffled, isTrue);
    expect(queue.previous(current: 'd'), 'c');
  });
}